# RecoupIQ ByteSDK Evaluation Archive (`windows-x64` & `linux-arm64`)

> [!IMPORTANT]
> Evaluation mode runs until `2027-02-28T23:59:59Z` (`RIQ_EVAL_EXPIRY_UNIX = 1803859199`). Unlock commercial mode offline at any time with an EdDSA licence token (`riq_activate_license_token()` in C or `riq_license.key` next to the CLI) with zero network calls and zero binary rebuilds.

## 1. Software Boundary Scope

This archive provides deterministic C99 byte-buffer libraries (`uint8_t*` input to `uint8_t*` output). Acoustic transducers, RS-485 voltage chips, and camera sensors stay inside the host hardware. All routines use fixed memory and zero dynamic heap allocation inside the core codecs.

## 2. Included Modules

1. **32-Byte Packetizer (`riq_seatrac32_*`):** Compresses ASCII and NMEA text and emits `<= 32-byte` SipHash-2-4 authenticated Reed-Solomon pieces. It is sized for 32-byte acoustic modem payloads. We did not test it with any modem. The encode call uses about 17 KB of RAM (two 7,568-byte work states and a 2,112-byte buffer, x86-64 build) plus your dictionary.
2. **FuelEU Maritime Check (`riq_fueleu_*`):** Compresses NMEA and flow-meter text logs. `riq_fueleu_meter_guard_ex` compares a measured flow series with an expected flow series that you supply, with a tolerance (default 5 %). It cannot see a pipe or a meter. Tests used synthetic data only. It seals `Regulation (EU) 2023/1805` gap records in a `BLAKE2b` chain.
3. **DORA `RT.02` Corporate LEI Gate (`riq_dora_*`):** Checks 20-character ISO 17442 Legal Entity Identifiers (`MOD 97-10`) and routes vendor rows to `APPROVE`, `DENY`, or `ABSTAIN` under `Regulation (EU) 2024/2956`.
4. **Edge GDPR Selective-Redaction Vault (`riq_gdpr_*`):** Removes fine spatial detail inside Personally Identifiable Information (PII) boxes, wipes raw pixels with `crypto_wipe()`, and outputs a `32-byte` keyed `BLAKE2b` receipt over the unredacted scene.

## 3. Run the 30-Second Bench Check

1. On Windows (`x86-64`), run `RUN_30_SECOND_OEM_EVAL.bat`.
2. On Linux (`aarch64` / Raspberry Pi 4 / vessel gateway), run `bash run_30_second_oem_eval.sh`.
3. Link `include/recoupiq_bytesdk.h` and `lib/librecoupiq_bytesdk.a` into your C99 or C++ firmware harness.
4. When moving to production (`https://recoupiq.github.io/bytesdk/` or `contact@recoup-iq.tech`), pass your offline EdDSA token to `riq_activate_license_token(token)` or save it to `riq_license.key`.

## 4. Licence

Read `EVALUATION_LICENCE.txt` before you use this archive. Evaluation use only, until 28 February 2027.
