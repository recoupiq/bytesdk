@echo off
setlocal
echo === RecoupIQ ByteSDK 30-Second Windows-x64 Bench Evaluation ===
"%~dp0windows-x64\bin\recoupiq_bytesdk_cli.exe" --self-test
if errorlevel 1 exit /b 1
"%~dp0windows-x64\bin\recoupiq_bytesdk_cli.exe" dora-check "%~dp0samples\sample_uk_gleif_100_leis.tsv"
if errorlevel 1 exit /b 1
"%~dp0windows-x64\bin\recoupiq_bytesdk_cli.exe" seatrac32-demo "%~dp0samples\sample_uk_sevenstones_62107.txt"
if errorlevel 1 exit /b 1
"%~dp0windows-x64\bin\recoupiq_bytesdk_cli.exe" gdpr-scrub "%~dp0samples\sample_kodak_128x128.pgm" "%TEMP%\riq_redacted_eval.pgm" 32 32 96 96
if errorlevel 1 exit /b 1
echo === ALL WINDOWS-X64 EVALUATION CHECKS PASSED ===
