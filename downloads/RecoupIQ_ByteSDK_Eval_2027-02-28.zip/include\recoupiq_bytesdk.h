/* RecoupIQ Byte-Boundary & Pure-Software Evaluation SDK (C99 API)
 * Scope: OSI Layer 2/6 deterministic byte-array transformations (uint8_t* in -> uint8_t* out).
 * Hardware transceivers, acoustic transducers, and RS-485 voltage drivers remain inside the host OEM device.
 * Evaluation builds expire after 2027-02-28T23:59:59Z (Unix epoch 1803859199).
 */
#ifndef RECOUPIQ_BYTESDK_H
#define RECOUPIQ_BYTESDK_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define RIQ_EVAL_EXPIRY_UNIX 1803859199ULL /* 2027-02-28T23:59:59Z */
#define RIQ_SEATRAC_MAX_BYTES 32u

enum {
    RIQ_OK                =  0,
    RIQ_ERR_EXPIRED       = -1,
    RIQ_ERR_PARAM         = -2,
    RIQ_ERR_BUFFER_SMALL  = -3,
    RIQ_ERR_NOT_AUTHENTIC = -4,
    RIQ_ERR_INCOMPLETE    = -5
};

enum {
    RIQ_DORA_APPROVE = 0,
    RIQ_DORA_DENY    = 1,
    RIQ_DORA_ABSTAIN = 2
};

typedef struct {
    uint16_t x0, y0, x1, y1;
} riq_roi_box;

/* Returns RIQ_OK if within evaluation window (<= 2027-02-28 UTC) or unlocked via EdDSA token, else RIQ_ERR_EXPIRED. */
int riq_eval_check(void);
const char* riq_eval_expiry_iso8601(void);

/* Offline EdDSA commercial licence unlock (zero network calls, zero binary rebuild).
 * Token format: "RIQLIC1:<customer_slug>:<expiry_unix_or_0>:<128_hex_eddsa_sig>"
 * Returns RIQ_OK if authentic and unexpired, RIQ_ERR_NOT_AUTHENTIC if forged, RIQ_ERR_EXPIRED if past token expiry.
 */
int riq_activate_license_token(const char* token);
int riq_is_licensed(void);
const char* riq_licensed_customer(void);

/* -------------------------------------------------------------------------
 * 1. Subsea 32-Byte Acoustic Packetizer (Blueprint Subsea SeaTrac / Sonardyne)
 *    Compresses ASCII/NMEA sensor cast in 7.5 KB MCU RAM (npct_lite_8k) and
 *    emits <= 32-byte SipHash-2-4 authenticated Cauchy Reed-Solomon pieces.
 * ------------------------------------------------------------------------- */
int riq_seatrac32_encode_batch(const uint8_t key16[16],
                               uint16_t device_id,
                               uint32_t seq_no,
                               const uint8_t* dict_bytes, size_t dict_len,
                               const uint8_t* raw_nmea, size_t raw_len,
                               unsigned parity_frames,
                               uint8_t out_frames[][RIQ_SEATRAC_MAX_BYTES],
                               uint8_t out_frame_lens[],
                               unsigned max_frames,
                               unsigned* out_k_data,
                               unsigned* out_total_frames);

int riq_seatrac32_decode_pieces(const uint8_t key16[16],
                                const uint8_t* dict_bytes, size_t dict_len,
                                const uint8_t frames[][RIQ_SEATRAC_MAX_BYTES],
                                const uint8_t frame_lens[],
                                unsigned num_received_frames,
                                unsigned k_data_expected,
                                uint8_t* out_raw, size_t out_cap,
                                unsigned* out_forged_rejected);

/* -------------------------------------------------------------------------
 * 2. FuelEU Maritime (Regulation EU 2023/2025 -> 2023/1805) Meter-to-Verifier
 *    8K-RAM NMEA/MFM compressor, MFM-vs-SFOC dual-sensor guard, and BLAKE2b
 *    communication-gap surrogate hash-chain receipt.
 * ------------------------------------------------------------------------- */
int riq_fueleu_compress_8k(const uint8_t* dict_bytes, size_t dict_len,
                           const uint8_t* raw_ascii, size_t raw_len,
                           uint8_t* out_comp, size_t out_cap);

int riq_fueleu_decompress_8k(const uint8_t* dict_bytes, size_t dict_len,
                             const uint8_t* comp_bytes, size_t comp_len,
                             uint8_t* out_raw, size_t out_cap);

int riq_fueleu_meter_guard(const int32_t* mfm_flow_d_kgh,
                           const int32_t* sfoc_expected_d_kgh,
                           size_t n_samples);

int riq_fueleu_chain_gap_record(uint8_t chain_tip32[32],
                                const char* gap_record_ascii);

/* -------------------------------------------------------------------------
 * 3. DORA (Regulation EU 2024/2956) RT.02 Corporate LEI & Solvency Gate
 *    Pure-software ISO 17442 MOD 97-10 check-digit verifier + deterministic
 *    APPROVE / DENY / ABSTAIN router.
 * ------------------------------------------------------------------------- */
int riq_dora_verify_lei_iso17442(const char* lei20);

int riq_dora_route_vendor(const char* lei20,
                          int entity_active,
                          int registration_issued,
                          int insolvency_flag,
                          int unverified_psc_shift_gt25);

/* -------------------------------------------------------------------------
 * 4. Edge GDPR Selective-Redaction & Keyed BLAKE2b Non-ROI Scene Receipt
 *    Scrubs spatial high-frequency detail inside PII boxes, wipes raw source
 *    buffer via crypto_wipe(), and seals a 32-byte keyed BLAKE2b receipt over
 *    all unredacted background pixels + ROI coordinates.
 * ------------------------------------------------------------------------- */
int riq_gdpr_scrub_and_seal_u8(const uint8_t key32[32],
                               uint8_t* raw_to_wipe,
                               uint8_t* out_redacted,
                               uint32_t width,
                               uint32_t height,
                               const riq_roi_box* rois,
                               size_t num_rois,
                               uint8_t out_receipt32[32]);

int riq_gdpr_verify_receipt_u8(const uint8_t key32[32],
                               const uint8_t* redacted_img,
                               uint32_t width,
                               uint32_t height,
                               const riq_roi_box* rois,
                               size_t num_rois,
                               const uint8_t expected_receipt32[32]);

#ifdef __cplusplus
}
#endif

#endif /* RECOUPIQ_BYTESDK_H */
