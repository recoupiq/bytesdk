#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=== RecoupIQ ByteSDK 30-Second Linux-ARM64 Bench Evaluation ==="
chmod +x "$DIR/linux-arm64/bin/recoupiq_bytesdk_cli"
"$DIR/linux-arm64/bin/recoupiq_bytesdk_cli" --self-test
"$DIR/linux-arm64/bin/recoupiq_bytesdk_cli" dora-check "$DIR/samples/sample_uk_gleif_100_leis.tsv"
"$DIR/linux-arm64/bin/recoupiq_bytesdk_cli" seatrac32-demo "$DIR/samples/sample_uk_sevenstones_62107.txt"
"$DIR/linux-arm64/bin/recoupiq_bytesdk_cli" gdpr-scrub "$DIR/samples/sample_kodak_128x128.pgm" "/tmp/riq_redacted_eval.pgm" 32 32 96 96
rm -f "/tmp/riq_redacted_eval.pgm"
echo "=== ALL LINUX-ARM64 EVALUATION CHECKS PASSED ==="
