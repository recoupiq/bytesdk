/* RecoupIQ Byte-Boundary & Pure-Software Evaluation SDK (C99 API)
 * Scope: OSI Layer 2/6 deterministic byte-array transformations (uint8_t* in -> uint8_t* out).
 * Hardware transceivers, acoustic transducers, and RS-485 voltage drivers remain inside the host OEM device.
 * Evaluation builds expire after 2027-02-28T23:59:59Z (Unix epoch 1803859199).
 */
#ifndef RECOUPIQ_BYTESDK_H
#define RECOUPIQ_BYTESDK_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define RIQ_EVAL_EXPIRY_UNIX 1803859199ULL /* 2027-02-28T23:59:59Z */
#define RIQ_SEATRAC_MAX_BYTES 32u

enum {
    RIQ_OK                =  0,
    RIQ_ERR_EXPIRED       = -1,
    RIQ_ERR_PARAM         = -2,
    RIQ_ERR_BUFFER_SMALL  = -3,
    RIQ_ERR_NOT_AUTHENTIC = -4,
    RIQ_ERR_INCOMPLETE    = -5
};

enum {
    RIQ_DORA_APPROVE = 0,
    RIQ_DORA_DENY    = 1,
    RIQ_DORA_ABSTAIN = 2
};

typedef struct {
    uint16_t x0, y0, x1, y1;
} riq_roi_box;

/* Returns RIQ_OK if within evaluation window (<= 2027-02-28 UTC) or unlocked via EdDSA token, else RIQ_ERR_EXPIRED. */
int riq_eval_check(void);
const char* riq_eval_expiry_iso8601(void);

/* Offline EdDSA commercial licence unlock (zero network calls, zero binary rebuild).
 * Token format: "RIQLIC1:<customer_slug>:<expiry_unix_or_0>:<128_hex_eddsa_sig>"
 * Returns RIQ_OK if authentic and unexpired, RIQ_ERR_NOT_AUTHENTIC if forged, RIQ_ERR_EXPIRED if past token expiry.
 */
int riq_activate_license_token(const char* token);
int riq_is_licensed(void);
const char* riq_licensed_customer(void);

/* -------------------------------------------------------------------------
 * 1. 32-Byte Packetizer, sized for 32-byte acoustic modem payloads.
 *    Not tested with any modem.
 *    Compresses ASCII/NMEA sensor text with npct_lite_8k and emits <= 32-byte
 *    SipHash-2-4 authenticated Cauchy Reed-Solomon pieces.
 *    RAM: the encode call uses two static npct_lite_state_8k structs, a 2,112-byte
 *    stack buffer, and the caller's dictionary. See SALES_FACTS.md for sizes.
 * ------------------------------------------------------------------------- */
int riq_seatrac32_encode_batch(const uint8_t key16[16],
                               uint16_t device_id,
                               uint32_t seq_no,
                               const uint8_t* dict_bytes, size_t dict_len,
                               const uint8_t* raw_nmea, size_t raw_len,
                               unsigned parity_frames,
                               uint8_t out_frames[][RIQ_SEATRAC_MAX_BYTES],
                               uint8_t out_frame_lens[],
                               unsigned max_frames,
                               unsigned* out_k_data,
                               unsigned* out_total_frames);

int riq_seatrac32_decode_pieces(const uint8_t key16[16],
                                const uint8_t* dict_bytes, size_t dict_len,
                                const uint8_t frames[][RIQ_SEATRAC_MAX_BYTES],
                                const uint8_t frame_lens[],
                                unsigned num_received_frames,
                                unsigned k_data_expected,
                                uint8_t* out_raw, size_t out_cap,
                                unsigned* out_forged_rejected);

/* -------------------------------------------------------------------------
 * 2. FuelEU Maritime (Regulation (EU) 2023/1805) Meter-to-Verifier
 *    8K NMEA/MFM compressor, flow-vs-expected two-series check, and BLAKE2b
 *    communication-gap surrogate hash-chain receipt.
 * ------------------------------------------------------------------------- */
int riq_fueleu_compress_8k(const uint8_t* dict_bytes, size_t dict_len,
                           const uint8_t* raw_ascii, size_t raw_len,
                           uint8_t* out_comp, size_t out_cap);

int riq_fueleu_decompress_8k(const uint8_t* dict_bytes, size_t dict_len,
                             const uint8_t* comp_bytes, size_t comp_len,
                             uint8_t* out_raw, size_t out_cap);

/* OLD guard, kept only so old programs still link. Do not use it for fuel data.
 * It uses fixed absolute limits made for a different signal. It gives false
 * alarms on a steady pair and on 2 % noise. Use riq_fueleu_meter_guard_ex. */
int riq_fueleu_meter_guard(const int32_t* mfm_flow_d_kgh,
                           const int32_t* sfoc_expected_d_kgh,
                           size_t n_samples);

/* Relative meter check (added 2026-11-15).
 * It compares two series that the caller supplies: measured flow and expected
 * flow (same unit, values >= 0). It cannot see a physical pipe or meter.
 * tolerance_permille: 10..500; 0 means the default 50 (5 %).
 * n: 16..4096 samples. Integer only, no heap.
 * Returns RIQ_ERR_* (< 0) or a set of the flags below (0 = no flag). */
#define RIQ_FUEL_MIN_SAMPLES 16u
#define RIQ_FUEL_MAX_SAMPLES 4096u
#define RIQ_FUEL_DEFAULT_TOL_PERMILLE 50
#define RIQ_FUEL_FLAG_FROZEN 0x01 /* flow almost never changes, while expected moves more than the tolerance */
#define RIQ_FUEL_FLAG_BELOW  0x02 /* flow is below expected by more than the tolerance (whole window, or a run of samples) */
#define RIQ_FUEL_FLAG_ABOVE  0x04 /* flow is above expected by more than the tolerance (whole window, or a run of samples) */
#define RIQ_FUEL_FLAG_REPLAY 0x08 /* flow repeats exactly with a period of 3..16 samples, and expected does not */
int riq_fueleu_meter_guard_ex(const int32_t* flow,
                              const int32_t* expected,
                              size_t n,
                              int32_t tolerance_permille);

int riq_fueleu_chain_gap_record(uint8_t chain_tip32[32],
                                const char* gap_record_ascii);

/* -------------------------------------------------------------------------
 * 3. DORA (Regulation EU 2024/2956) RT.02 Corporate LEI & Solvency Gate
 *    Pure-software ISO 17442 MOD 97-10 check-digit verifier + deterministic
 *    APPROVE / DENY / ABSTAIN router.
 * ------------------------------------------------------------------------- */
int riq_dora_verify_lei_iso17442(const char* lei20);

int riq_dora_route_vendor(const char* lei20,
                          int entity_active,
                          int registration_issued,
                          int insolvency_flag,
                          int unverified_psc_shift_gt25);

/* -------------------------------------------------------------------------
 * 4. Edge GDPR Selective-Redaction & Keyed BLAKE2b Non-ROI Scene Receipt
 *    Scrubs spatial high-frequency detail inside PII boxes, wipes raw source
 *    buffer via crypto_wipe(), and seals a 32-byte keyed BLAKE2b receipt over
 *    all unredacted background pixels + ROI coordinates.
 * ------------------------------------------------------------------------- */
int riq_gdpr_scrub_and_seal_u8(const uint8_t key32[32],
                               uint8_t* raw_to_wipe,
                               uint8_t* out_redacted,
                               uint32_t width,
                               uint32_t height,
                               const riq_roi_box* rois,
                               size_t num_rois,
                               uint8_t out_receipt32[32]);

int riq_gdpr_verify_receipt_u8(const uint8_t key32[32],
                               const uint8_t* redacted_img,
                               uint32_t width,
                               uint32_t height,
                               const riq_roi_box* rois,
                               size_t num_rois,
                               const uint8_t expected_receipt32[32]);

#ifdef __cplusplus
}
#endif

#endif /* RECOUPIQ_BYTESDK_H */
